
CosmicDrop — Static Website Package
==================================

What this package contains:
- index.html            -> Today's Cosmic Drop (automatically rotates by date)
- archive.html          -> Archive of all drops (shows all 30)
- styles.css            -> Styling
- script.js             -> Logic to select today's drop and render archive
- data/drops.json       -> The 30 Cosmic Drops (titles, messages, affirmations, image prompts)
- assets/image-prompts.txt -> The image prompts for generating artwork
- README.md             -> This file

How the "auto-update" works:
- This is a static site that calculates which drop to show each day using the current date.
- You don't need a server or backend; the displayed drop changes automatically without you editing files.
- To make the site publish a new drop every day without manual edits, host it on GitHub Pages, Netlify, or any static-file host.

How to deploy (quick options):
1) GitHub Pages (free)
   - Create a new GitHub repository.
   - Upload all files from this package (you can drag & drop in the web UI).
   - In repository Settings -> Pages, set the source branch to 'main' and folder to '/'.
   - Your site will be available at https://<yourusername>.github.io/<repo>.

2) Netlify (recommended, also free for basic use)
   - Create a free Netlify account.
   - Drag & drop the zipped site folder into Netlify's 'Sites' -> 'Add new site' -> 'Deploy manually'.
   - Netlify will host it at a *.netlify.app URL; you can connect your domain CosmicDrop.com if you own it.

3) Vercel or any static host (similar steps).

Optional upgrades (next steps I can do for you):
- Convert this into a WordPress theme or a full WordPress site (requires hosting & WP install).
- Hook up automated image generation (OpenAI / Midjourney / Stability) + daily image uploads via Make.com or Zapier.
- Add real email capture (Mailchimp / ConvertKit) and automated daily mailing.
- Add SEO meta tags, OG images, and social share templates.

If you want I can:
- Generate the site zip and provide the download link (I have already created it below).
- Provide step-by-step screenshots for deploying to Netlify or GitHub Pages.
- Create code for a simple Netlify build (redirects, headers) or a GitHub Actions workflow.

Generated on: 2025-12-03T08:47:58.456168 UTC


## Automation


To enable automatic daily updates using GitHub Actions:

1. Create a GitHub repository and push this site.
2. In the repository Settings -> Secrets -> Actions add:
   - OPENAI_API_KEY : your OpenAI API key
   - IMAGE_MODEL : optional (e.g. gpt-image-1)
3. Enable GitHub Pages (if you want Github Pages hosting) or connect the repo to Netlify/Vercel.
4. The workflow `.github/workflows/daily.yml` runs daily and will:
   - Call OpenAI to generate a new Cosmic Drop
   - Create an image and save it to assets/images/
   - Commit & push changes back to the repo (so the archive grows)
