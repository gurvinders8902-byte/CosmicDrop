
#!/usr/bin/env python3
"""
generate_drop.py

This script:
- Generates one new "Cosmic Drop" using OpenAI (text + image)
- Appends it to data/drops.json (keeps a rolling archive)
- Saves generated image to assets/images/
- Commits and pushes changes (when run in CI with git config)

REQUIREMENTS:
- environment variables: OPENAI_API_KEY
- optional: IMAGE_MODEL (default: "gpt-image-1" or use other provider)
- git must be available and configured in CI (GitHub Actions provides GITHUB_TOKEN)
"""
import os
import json
import base64
from datetime import datetime
from pathlib import Path
import openai
import requests

# Config
BASE_DIR = Path(__file__).resolve().parent.parent
DATA_PATH = BASE_DIR / "data" / "drops.json"
ASSETS_IMG_DIR = BASE_DIR / "assets" / "images"
ASSETS_IMG_DIR.mkdir(parents=True, exist_ok=True)

# Load API key
OPENAI_API_KEY = os.environ.get("OPENAI_API_KEY")
if not OPENAI_API_KEY:
    raise SystemExit("OPENAI_API_KEY not set in environment (secret).")
openai.api_key = OPENAI_API_KEY

# Load existing drops
with open(DATA_PATH, "r", encoding="utf-8") as f:
    drops = json.load(f)

# Create prompt to generate a new Cosmic Drop
prompt = """
Create a single mystical "Cosmic Drop" entry formatted as JSON with keys:
- title (3-6 words)
- message (1-2 short lines)
- affirmation (short)
- image_prompt (a concise but vivid prompt for an AI image generator, max 20 words)
Tone: mysterious, uplifting, cosmic.
Return only valid JSON.
"""

# Call OpenAI ChatCompletion
resp = openai.ChatCompletion.create(
    model="gpt-4o-mini", # adjust if unavailable; GitHub Actions user must have access
    messages=[{"role":"system","content":"You are a mystical creative assistant."},
              {"role":"user","content":prompt}],
    max_tokens=200,
    temperature=0.9,
)

# Parse response
text = resp.choices[0].message.content.strip()
import json, re
# Try to extract JSON from response
m = re.search(r'(\{.*\})', text, re.S)
if m:
    jtxt = m.group(1)
else:
    jtxt = text
new = json.loads(jtxt)

# Add index/day
new_entry = {
    "day": len(drops) + 1,
    "title": new.get("title", "Untitled Drop"),
    "message": new.get("message", ""),
    "affirmation": new.get("affirmation", ""),
    "image_prompt": new.get("image_prompt", "")
}

# Generate image via OpenAI Images API (if supported) - fallback to placeholder if not
image_filename = f"drop_{new_entry['day']:03d}.png"
image_path = ASSETS_IMG_DIR / image_filename

try:
    img_resp = openai.Image.create(
        model=os.environ.get("IMAGE_MODEL","gpt-image-1"),
        prompt=new_entry["image_prompt"],
        size="1024x1024"
    )
    img_b64 = img_resp.data[0].b64_json
    with open(image_path, "wb") as imgf:
        imgf.write(base64.b64decode(img_b64))
    new_entry["image_file"] = str(Path("assets/images") / image_filename)
except Exception as e:
    print("Image generation failed:", e)
    new_entry["image_file"] = ""

# Append to drops
drops.append(new_entry)
with open(DATA_PATH, "w", encoding="utf-8") as f:
    json.dump(drops, f, ensure_ascii=False, indent=2)

print("Generated new drop:", new_entry["title"])

# If running in CI we can commit changes using git (GitHub Actions uses GITHUB_ACTOR and token)
if os.environ.get("GITHUB_ACTIONS") == "true":
    import subprocess
    subprocess.run(["git", "config", "--global", "user.name", "github-actions[bot]"], check=True)
    subprocess.run(["git", "config", "--global", "user.email", "github-actions[bot]@users.noreply.github.com"], check=True)
    subprocess.run(["git", "add", str(DATA_PATH), str(image_path)], check=False)
    commit_msg = f"chore: add cosmic drop {new_entry['day']:03d} - {new_entry['title']}"
    subprocess.run(["git", "commit", "-m", commit_msg], check=False)
    # Push using the GITHUB_TOKEN (the runner sets up origin)
    subprocess.run(["git", "push"], check=False)
