
// CosmicDrop static site script
async function loadDrops(){
  const res = await fetch('data/drops.json');
  const drops = await res.json();
  return drops;
}

function pickTodayIndex(drops){
  // Use UTC date to pick a rotating drop based on day count since a fixed epoch
  const epoch = new Date('2025-01-01T00:00:00Z');
  const now = new Date();
  const days = Math.floor((Date.UTC(now.getUTCFullYear(),now.getUTCMonth(),now.getUTCDate()) - epoch.getTime()) / (1000*60*60*24));
  // Cycle through drops length
  return days % drops.length;
}

function renderDrop(drop){
  document.getElementById('drop-title').textContent = drop.title;
  document.getElementById('drop-message').textContent = drop.message;
  document.getElementById('drop-affirmation').textContent = '"' + drop.affirmation + '"';
  // simple image placeholder: use the prompt as alt text
  const imgDiv = document.getElementById('drop-image');
  imgDiv.textContent = '';
  const el = document.createElement('div');
  el.className = 'prompt-box';
  el.textContent = 'Image prompt: ' + drop.image_prompt;
  el.style.padding = '14px';
  el.style.fontSize = '14px';
  el.style.color = '#cfdcff';
  imgDiv.appendChild(el);
}

function renderArchive(drops){
  const list = document.getElementById('archive-list');
  if(!list) return;
  list.innerHTML = '';
  drops.forEach(d=>{
    const card = document.createElement('section');
    card.className = 'card';
    const h = document.createElement('h3');
    h.textContent = d.title;
    const p = document.createElement('p');
    p.textContent = d.message;
    const a = document.createElement('p');
    a.className = 'affirmation';
    a.textContent = '"' + d.affirmation + '"';
    const prompt = document.createElement('p');
    prompt.style.marginTop='8px';
    prompt.style.fontSize='13px';
    prompt.style.color='#9fb0df';
    prompt.textContent = 'Prompt: ' + d.image_prompt;
    card.appendChild(h);
    card.appendChild(p);
    card.appendChild(a);
    card.appendChild(prompt);
    list.appendChild(card);
  });
}

document.addEventListener('DOMContentLoaded', async ()=>{
  const drops = await loadDrops();
  const idx = pickTodayIndex(drops);
  renderDrop(drops[idx]);
  renderArchive(drops);

  // reveal button: pick a random other drop
  document.getElementById('reveal-btn').addEventListener('click', ()=>{
    const rnd = Math.floor(Math.random()*drops.length);
    renderDrop(drops[rnd]);
  });

  // email form (placeholder)
  document.getElementById('email-form').addEventListener('submit', (e)=>{
    e.preventDefault();
    const email = document.getElementById('email').value;
    alert('Thanks! To activate email delivery, connect your Mail provider. Email captured: ' + email);
    document.getElementById('email').value = '';
  });
});
